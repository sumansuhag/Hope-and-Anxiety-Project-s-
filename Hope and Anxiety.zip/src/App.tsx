import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { HopeAssessment } from './components/HopeAssessment';
import { DailyNudge } from './components/DailyNudge';
import { InsightDashboard } from './components/InsightDashboard';
import { Onboarding } from './components/Onboarding';
import { getProfile, getTodayScore } from './utils/storage';
import { HopeScore } from './types';
import { Leaf, Menu, X } from 'lucide-react';

function App() {
  const [profile, setProfile] = useState(getProfile());
  const [todayScore, setTodayScore] = useState<HopeScore | null>(null);
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    setProfile(getProfile());
    setTodayScore(getTodayScore());
  }, []);

  const handleScoreComplete = (score: HopeScore) => {
    setTodayScore(score);
  };

  const handleReset = () => {
    localStorage.clear();
    window.location.reload();
  };

  if (!profile.onboardingComplete) {
    return <Onboarding onComplete={() => setProfile(getProfile())} />;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-100 rounded-lg">
              <Leaf className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-slate-800">HopeTrack</h1>
              <p className="text-xs text-slate-500">
                {format(new Date(), 'EEEE, MMMM d')}
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowMenu(!showMenu)}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            {showMenu ? <X className="w-5 h-5 text-slate-600" /> : <Menu className="w-5 h-5 text-slate-600" />}
          </button>
        </div>
        
        {showMenu && (
          <div className="border-t border-slate-100 bg-white">
            <div className="max-w-lg mx-auto px-4 py-3">
              <button
                onClick={handleReset}
                className="text-sm text-slate-500 hover:text-red-600 transition-colors"
              >
                Reset all data
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <HopeAssessment 
          onComplete={handleScoreComplete}
          existingScore={todayScore}
        />
        
        <DailyNudge todayScore={todayScore?.score} />
        
        <InsightDashboard />
      </main>

      {/* Footer */}
      <footer className="mt-12 py-8 border-t border-slate-200 bg-white">
        <div className="max-w-lg mx-auto px-4 text-center">
          <p className="text-xs text-slate-500">
            Based on Snyder's Hope Theory • Your data stays on your device
          </p>
          <p className="text-xs text-slate-400 mt-2">
            HopeTrack • Measure. Cultivate. Grow.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;