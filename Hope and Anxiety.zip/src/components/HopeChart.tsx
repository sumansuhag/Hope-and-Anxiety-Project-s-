import { HopeScore } from '../types';
import { getScoreCategory } from '../utils/hopeScale';

interface HopeChartProps {
  scores: HopeScore[];
}

export function HopeChart({ scores }: HopeChartProps) {
  const getLast7Days = () => {
    const days: string[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      days.push(date.toDateString());
    }
    return days;
  };

  const last7Days = getLast7Days();
  const chartData = last7Days.map(date => {
    const score = scores.find(s => s.date === date);
    return {
      date,
      score: score?.score || null,
      day: new Date(date).toLocaleDateString('en-US', { weekday: 'short' })
    };
  });

  const maxScore = 30;
  const chartHeight = 120;
  const chartWidth = 280;
  const padding = { top: 10, bottom: 20, left: 30, right: 10 };

  const getX = (index: number) => 
    padding.left + (index * (chartWidth - padding.left - padding.right) / (chartData.length - 1));
  
  const getY = (score: number) => 
    chartHeight - padding.bottom - ((score / maxScore) * (chartHeight - padding.top - padding.bottom));

  const getLineColor = () => {
    const recentScores = chartData.filter(d => d.score !== null).map(d => d.score!);
    if (recentScores.length === 0) return '#94a3b8';
    
    const avg = recentScores.reduce((a, b) => a + b, 0) / recentScores.length;
    if (avg <= 12) return '#dc2626';
    if (avg <= 20) return '#d97706';
    return '#059669';
  };

  const lineColor = getLineColor();

  return (
    <div className="w-full">
      <svg width={chartWidth} height={chartHeight} className="mx-auto">
        {/* Grid lines */}
        {[0, 10, 20, 30].map((value) => (
          <g key={value}>
            <line
              x1={padding.left}
              y1={getY(value)}
              x2={chartWidth - padding.right}
              y2={getY(value)}
              stroke="#e2e8f0"
              strokeWidth={1}
              strokeDasharray="4 4"
            />
            <text
              x={padding.left - 5}
              y={getY(value) + 4}
              textAnchor="end"
              className="text-xs fill-slate-400"
            >
              {value}
            </text>
          </g>
        ))}

        {/* X-axis labels */}
        {chartData.map((d, i) => (
          <text
            key={d.date}
            x={getX(i)}
            y={chartHeight - 2}
            textAnchor="middle"
            className="text-xs fill-slate-400"
          >
            {d.day}
          </text>
        ))}

        {/* Data line */}
        {chartData.some(d => d.score !== null) && (
          <polyline
            points={chartData
              .map((d, i) => d.score !== null ? `${getX(i)},${getY(d.score)}` : null)
              .filter(Boolean)
              .join(' ')}
            fill="none"
            stroke={lineColor}
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {/* Data points */}
        {chartData.map((d, i) => {
          if (d.score === null) return null;
          const category = getScoreCategory(d.score);
          return (
            <circle
              key={d.date}
              cx={getX(i)}
              cy={getY(d.score)}
              r={4}
              fill={category.bgColor.replace('bg-', '').replace('-50', '')}
              stroke={lineColor}
              strokeWidth={2}
            />
          );
        })}
      </svg>
    </div>
  );
}