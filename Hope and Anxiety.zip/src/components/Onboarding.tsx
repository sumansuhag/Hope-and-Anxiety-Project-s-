import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { saveProfile } from '../utils/storage';
import { Leaf, Heart, ArrowRight } from 'lucide-react';

interface OnboardingProps {
  onComplete: () => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [age, setAge] = useState('');
  const [step, setStep] = useState(0);

  const handleContinue = () => {
    if (step === 0) {
      setStep(1);
    } else {
      saveProfile({
        age: parseInt(age) || undefined,
        onboardingComplete: true
      });
      onComplete();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50">
      <Card className="w-full max-w-md border-emerald-200">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-emerald-100 rounded-full">
              <Leaf className="w-8 h-8 text-emerald-600" />
            </div>
          </div>
          <CardTitle className="text-2xl text-emerald-800">Welcome to HopeTrack</CardTitle>
          <CardDescription className="text-emerald-600">
            Measure. Cultivate. Grow.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {step === 0 ? (
            <div className="space-y-4">
              <div className="bg-emerald-50 p-4 rounded-lg">
                <p className="text-sm text-emerald-800 leading-relaxed">
                  Hope isn't just wishful thinking — it's a measurable strength. 
                  Based on decades of research, we'll help you track your hope 
                  and build it through small, daily practices.
                </p>
              </div>
              
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-3 bg-slate-50 rounded-lg">
                  <Heart className="w-6 h-6 text-rose-500 mx-auto mb-2" />
                  <div className="text-xs text-slate-600">Assess</div>
                </div>
                <div className="text-center p-3 bg-slate-50 rounded-lg">
                  <ArrowRight className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                  <div className="text-xs text-slate-600">Track</div>
                </div>
                <div className="text-center p-3 bg-slate-50 rounded-lg">
                  <Leaf className="w-6 h-6 text-emerald-500 mx-auto mb-2" />
                  <div className="text-xs text-slate-600">Grow</div>
                </div>
              </div>
              
              <Button 
                onClick={handleContinue}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Get Started
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <Label htmlFor="age" className="text-slate-700">
                  How old are you? (optional)
                </Label>
                <Input
                  id="age"
                  type="number"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="Enter your age"
                  className="mt-2 border-slate-200"
                  min="1"
                  max="120"
                />
                <p className="text-xs text-slate-500 mt-2">
                  This helps us personalize your hope profile. Your data stays private on your device.
                </p>
              </div>
              
              <Button 
                onClick={handleContinue}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Begin My Hope Journey
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}