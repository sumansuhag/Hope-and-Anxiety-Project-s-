import { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { ASSESSMENT_QUESTIONS, calculateScore, getScoreCategory } from '../utils/hopeScale';
import { saveScore } from '../utils/storage';
import { HopeScore } from '../types';

interface HopeAssessmentProps {
  onComplete: (score: HopeScore) => void;
  existingScore?: HopeScore | null;
}

export function HopeAssessment({ onComplete, existingScore }: HopeAssessmentProps) {
  const [responses, setResponses] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState(!!existingScore);

  const handleSubmit = () => {
    const result = calculateScore(responses);
    const score: HopeScore = {
      date: new Date().toDateString(),
      score: result.total,
      agency: result.agency,
      pathways: result.pathways
    };
    
    saveScore(score);
    setSubmitted(true);
    onComplete(score);
  };

  const handleRetake = () => {
    setResponses({});
    setSubmitted(false);
  };

  if (submitted && existingScore) {
    const category = getScoreCategory(existingScore.score);
    
    return (
      <Card className="border-emerald-200 bg-emerald-50/50">
        <CardHeader>
          <CardTitle className="text-emerald-800">Today's Hope Score</CardTitle>
          <CardDescription className="text-emerald-600">
            Based on Snyder's Hope Theory
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center py-6">
            <div className={`text-6xl font-bold ${category.color} mb-2`}>
              {existingScore.score}
            </div>
            <div className={`text-lg font-medium ${category.textColor}`}>
              {category.label}
            </div>
            <div className="text-sm text-slate-500 mt-2">
              out of 30 possible
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-emerald-200">
            <div className="text-center">
              <div className="text-2xl font-semibold text-slate-700">{existingScore.agency}</div>
              <div className="text-xs text-slate-500">Agency</div>
              <div className="text-xs text-slate-400">Motivation</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-semibold text-slate-700">{existingScore.pathways}</div>
              <div className="text-xs text-slate-500">Pathways</div>
              <div className="text-xs text-slate-400">Finding ways</div>
            </div>
          </div>
          
          <Button 
            onClick={handleRetake}
            variant="outline"
            className="w-full mt-4 border-emerald-300 text-emerald-700 hover:bg-emerald-100"
          >
            Retake Assessment
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-slate-200">
      <CardHeader>
        <CardTitle className="text-slate-800">Hope Assessment</CardTitle>
        <CardDescription className="text-slate-600">
          Rate each statement from 1 (Strongly Disagree) to 5 (Strongly Agree)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {ASSESSMENT_QUESTIONS.map((question, index) => (
          <div key={question.id} className="space-y-3">
            <Label className="text-sm font-medium text-slate-700 leading-relaxed">
              {index + 1}. {question.text}
            </Label>
            <RadioGroup
              value={responses[question.id]?.toString()}
              onValueChange={(value) => 
                setResponses({ ...responses, [question.id]: parseInt(value) })
              }
              className="flex justify-between"
            >
              {[1, 2, 3, 4, 5].map((value) => (
                <div key={value} className="flex flex-col items-center gap-1">
                  <RadioGroupItem 
                    value={value.toString()} 
                    id={`${question.id}-${value}`}
                    className="border-slate-300"
                  />
                  <Label 
                    htmlFor={`${question.id}-${value}`}
                    className="text-xs text-slate-500 cursor-pointer"
                  >
                    {value}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        ))}
        
        <Button 
          onClick={handleSubmit}
          disabled={Object.keys(responses).length < ASSESSMENT_QUESTIONS.length}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          See My Hope Score
        </Button>
      </CardContent>
    </Card>
  );
}