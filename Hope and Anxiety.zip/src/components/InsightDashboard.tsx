import { getScores } from '../utils/storage';
import { generateInsight, getHopeProfile } from '../utils/hopeScale';
import { getProfile } from '../utils/storage';
import { HopeChart } from './HopeChart';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { TrendingUp, Minus, TrendingDown, User, Calendar } from 'lucide-react';

export function InsightDashboard() {
  const scores = getScores();
  const profile = getProfile();
  const insight = generateInsight(scores);
  const hopeProfile = getHopeProfile(profile.age, insight.averageScore);

  const getTrendIcon = () => {
    switch (insight.trend) {
      case 'improving':
        return <TrendingUp className="w-5 h-5 text-emerald-600" />;
      case 'declining':
        return <TrendingDown className="w-5 h-5 text-red-600" />;
      default:
        return <Minus className="w-5 h-5 text-slate-400" />;
    }
  };

  const getTrendColor = () => {
    switch (insight.trend) {
      case 'improving':
        return 'text-emerald-600 bg-emerald-50';
      case 'declining':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-slate-600 bg-slate-50';
    }
  };

  return (
    <div className="space-y-4">
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-slate-800 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-slate-500" />
            Weekly Overview
          </CardTitle>
          <CardDescription className="text-slate-600">
            Your hope patterns over the last 7 days
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <HopeChart scores={scores} />
          
          <div className={`flex items-start gap-3 p-3 rounded-lg ${getTrendColor()}`}>
            {getTrendIcon()}
            <p className="text-sm leading-relaxed">{insight.message}</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-slate-800 flex items-center gap-2">
            <User className="w-5 h-5 text-slate-500" />
            Your Hope Profile
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-slate-50 p-4 rounded-lg">
            <div className="text-lg font-semibold text-slate-800 mb-1">
              {hopeProfile}
            </div>
            <div className="text-sm text-slate-600">
              Weekly average: <span className="font-medium">{insight.averageScore}</span>/30
            </div>
          </div>
          
          {scores.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-100">
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-xl font-bold text-slate-700">
                    {scores.length}
                  </div>
                  <div className="text-xs text-slate-500">Days tracked</div>
                </div>
                <div>
                  <div className="text-xl font-bold text-emerald-600">
                    {Math.max(...scores.map(s => s.score))}
                  </div>
                  <div className="text-xs text-slate-500">Highest</div>
                </div>
                <div>
                  <div className="text-xl font-bold text-slate-400">
                    {Math.min(...scores.map(s => s.score))}
                  </div>
                  <div className="text-xs text-slate-500">Lowest</div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}