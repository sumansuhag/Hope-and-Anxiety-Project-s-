import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { getPromptForScore, getDailyQuote } from '../utils/prompts';
import { saveReflection, getTodayReflection } from '../utils/storage';
import { Star, ArrowRight, Check, Heart, Users, Mail, Shield, Clock, ArrowUp, Leaf, Edit, Calendar, Sparkles, Sun, MessageCircle, Target, Lightbulb } from 'lucide-react';

interface DailyNudgeProps {
  todayScore?: number;
}

const ICON_MAP: Record<string, any> = {
  Star, ArrowRight, Check, Heart, Users, Mail, Shield, Clock, ArrowUp, Leaf, Edit, Calendar, Sparkles, Sun, MessageCircle, Target, Lightbulb
};

export function DailyNudge({ todayScore }: DailyNudgeProps) {
  const [reflection, setReflection] = useState('');
  const [completed, setCompleted] = useState(false);
  const [prompt, setPrompt] = useState(getPromptForScore(todayScore || 15));
  const [quote] = useState(getDailyQuote());

  useEffect(() => {
    const todayRef = getTodayReflection();
    if (todayRef) {
      setReflection(todayRef.reflection);
      setCompleted(todayRef.completed);
    }
  }, []);

  useEffect(() => {
    if (todayScore !== undefined) {
      setPrompt(getPromptForScore(todayScore));
    }
  }, [todayScore]);

  const handleComplete = () => {
    const newReflection = {
      date: new Date().toDateString(),
      promptId: prompt.id,
      reflection,
      completed: true
    };
    saveReflection(newReflection);
    setCompleted(true);
  };

  const IconComponent = ICON_MAP[prompt.icon] || Lightbulb;

  return (
    <Card className="border-amber-200 bg-amber-50/50">
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-100 rounded-lg">
            <IconComponent className="w-5 h-5 text-amber-600" />
          </div>
          <div>
            <CardTitle className="text-amber-800">Daily Hope Nudge</CardTitle>
            <CardDescription className="text-amber-600">
              A small step toward building hope
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-white p-4 rounded-lg border border-amber-100">
          <p className="text-slate-700 leading-relaxed">{prompt.text}</p>
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-600">
            Reflect (optional)
          </label>
          <Textarea
            value={reflection}
            onChange={(e) => setReflection(e.target.value)}
            placeholder="Take a moment to write your thoughts..."
            className="min-h-20 border-slate-200 focus:border-amber-300"
            disabled={completed}
          />
        </div>
        
        {!completed ? (
          <Button 
            onClick={handleComplete}
            className="w-full bg-amber-600 hover:bg-amber-700 text-white"
          >
            Mark as Done
          </Button>
        ) : (
          <div className="flex items-center justify-center gap-2 text-emerald-600 py-2">
            <Check className="w-5 h-5" />
            <span className="font-medium">Completed today</span>
          </div>
        )}
        
        <div className="pt-4 border-t border-amber-200">
          <p className="text-xs text-slate-500 italic text-center">
            "{quote.text}"
          </p>
          <p className="text-xs text-slate-400 text-center mt-1">— {quote.author}</p>
        </div>
      </CardContent>
    </Card>
  );
}