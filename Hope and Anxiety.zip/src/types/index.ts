export interface HopeScore {
  date: string;
  score: number;
  agency: number;
  pathways: number;
}

export interface DailyPrompt {
  id: string;
  text: string;
  category: 'small-wins' | 'therapeutic-connection' | 'growth' | 'future-orientation';
  icon: string;
}

export interface UserReflection {
  date: string;
  promptId: string;
  reflection: string;
  completed: boolean;
}

export interface UserProfile {
  age?: number;
  onboardingComplete: boolean;
}

export interface WeeklyInsight {
  trend: 'improving' | 'stable' | 'declining';
  averageScore: number;
  message: string;
}