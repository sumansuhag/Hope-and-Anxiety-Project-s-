import { HopeScore } from '../types';

export const ASSESSMENT_QUESTIONS = [
  // Agency questions (1-3)
  { id: 'agency-1', text: 'I can think of many ways to get out of a jam.', type: 'agency' as const },
  { id: 'agency-2', text: 'I energetically pursue my goals.', type: 'agency' as const },
  { id: 'agency-3', text: 'I feel tired most of the time.', type: 'agency' as const, reverse: true },
  // Pathways questions (4-6)
  { id: 'pathways-1', text: 'There are lots of ways around any problem.', type: 'pathways' as const },
  { id: 'pathways-2', text: 'I can think of many ways to get the things in life that are important to me.', type: 'pathways' as const },
  { id: 'pathways-3', text: 'Even when others get discouraged, I know I can find a way to solve the problem.', type: 'pathways' as const }
];

export function calculateScore(responses: Record<string, number>): {
  total: number;
  agency: number;
  pathways: number;
} {
  let agency = 0;
  let pathways = 0;
  
  ASSESSMENT_QUESTIONS.forEach(question => {
    const value = responses[question.id] || 3;
    const adjustedValue = question.reverse ? 6 - value : value;
    
    if (question.type === 'agency') {
      agency += adjustedValue;
    } else {
      pathways += adjustedValue;
    }
  });
  
  return {
    total: agency + pathways,
    agency,
    pathways
  };
}

export function getScoreCategory(score: number): {
  label: string;
  color: string;
  bgColor: string;
  textColor: string;
} {
  if (score <= 12) {
    return {
      label: 'Low Hope',
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      textColor: 'text-red-700'
    };
  } else if (score <= 20) {
    return {
      label: 'Moderate Hope',
      color: 'text-amber-600',
      bgColor: 'bg-amber-50',
      textColor: 'text-amber-700'
    };
  } else {
    return {
      label: 'High Hope',
      color: 'text-emerald-600',
      bgColor: 'bg-emerald-50',
      textColor: 'text-emerald-700'
    };
  }
}

export function generateInsight(scores: HopeScore[]): {
  trend: 'improving' | 'stable' | 'declining';
  averageScore: number;
  message: string;
} {
  if (scores.length < 2) {
    return {
      trend: 'stable',
      averageScore: scores[0]?.score || 15,
      message: 'Keep tracking to see your hope patterns emerge.'
    };
  }
  
  const recent = scores.slice(-7);
  const averageScore = Math.round(recent.reduce((sum, s) => sum + s.score, 0) / recent.length);
  
  const firstHalf = recent.slice(0, Math.floor(recent.length / 2));
  const secondHalf = recent.slice(Math.floor(recent.length / 2));
  
  const firstAvg = firstHalf.reduce((sum, s) => sum + s.score, 0) / firstHalf.length;
  const secondAvg = secondHalf.reduce((sum, s) => sum + s.score, 0) / secondHalf.length;
  
  let trend: 'improving' | 'stable' | 'declining';
  let message: string;
  
  if (secondAvg > firstAvg + 1) {
    trend = 'improving';
    message = 'You\'ve shown consistent hope growth this week — your small wins are building momentum.';
  } else if (secondAvg < firstAvg - 1) {
    trend = 'declining';
    message = 'Your hope dipped midweek. Try reconnecting with someone who sees your strength.';
  } else {
    trend = 'stable';
    message = 'Your hope remains steady. Consistency is the foundation of growth.';
  }
  
  return { trend, averageScore, message };
}

export function getHopeProfile(age?: number, averageScore?: number): string {
  if (!age) return 'Hope Explorer';
  
  if (age < 25) {
    return 'Situational Hope Seeker';
  } else if (averageScore && averageScore >= 21) {
    return 'Resilient Hope Builder';
  } else if (age >= 26) {
    return 'Steady Hope Cultivator';
  }
  
  return 'Hope Explorer';
}