import { DailyPrompt } from '../types';

export const PROMPTS: DailyPrompt[] = [
  // Small Wins
  {
    id: 'small-win-1',
    text: 'Notice one small win today — even getting out of bed counts.',
    category: 'small-wins',
    icon: 'Star'
  },
  {
    id: 'small-win-2',
    text: 'What is one tiny step you can take right now? Just one.',
    category: 'small-wins',
    icon: 'ArrowRight'
  },
  {
    id: 'small-win-3',
    text: 'Celebrate completing a task you\'ve been putting off.',
    category: 'small-wins',
    icon: 'Check'
  },
  {
    id: 'small-win-4',
    text: 'Name three things that went well today, no matter how small.',
    category: 'small-wins',
    icon: 'Heart'
  },
  {
    id: 'small-win-5',
    text: 'Acknowledge one way you showed up for yourself today.',
    category: 'small-wins',
    icon: 'User'
  },
  
  // Therapeutic Connection
  {
    id: 'connection-1',
    text: 'Reach out to one person who believes in you.',
    category: 'therapeutic-connection',
    icon: 'Users'
  },
  {
    id: 'connection-2',
    text: 'Share your current struggle with someone you trust.',
    category: 'therapeutic-connection',
    icon: 'Mail'
  },
  {
    id: 'connection-3',
    text: 'Think of someone who makes you feel safe. What qualities do they have?',
    category: 'therapeutic-connection',
    icon: 'Shield'
  },
  {
    id: 'connection-4',
    text: 'Send a message of appreciation to someone who\'s supported you.',
    category: 'therapeutic-connection',
    icon: 'Heart'
  },
  {
    id: 'connection-5',
    text: 'Remember a time someone helped you through a hard moment.',
    category: 'therapeutic-connection',
    icon: 'Clock'
  },
  
  // Growth
  {
    id: 'growth-1',
    text: 'What challenge have you overcome that you once thought impossible?',
    category: 'growth',
    icon: 'ArrowUp'
  },
  {
    id: 'growth-2',
    text: 'How are you different today than you were a year ago?',
    category: 'growth',
    icon: 'Leaf'
  },
  {
    id: 'growth-3',
    text: 'What strength have you developed through recent difficulties?',
    category: 'growth',
    icon: 'Star'
  },
  {
    id: 'growth-4',
    text: 'Write down one lesson you\'ve learned this week.',
    category: 'growth',
    icon: 'Edit'
  },
  {
    id: 'growth-5',
    text: 'What would you tell your past self about where you are now?',
    category: 'growth',
    icon: 'MessageCircle'
  },
  
  // Future Orientation
  {
    id: 'future-1',
    text: 'Imagine your ideal future. What does it look like in one year?',
    category: 'future-orientation',
    icon: 'Calendar'
  },
  {
    id: 'future-2',
    text: 'What is one goal you\'re working toward, however small?',
    category: 'future-orientation',
    icon: 'Target'
  },
  {
    id: 'future-3',
    text: 'List three possibilities that excite you about the future.',
    category: 'future-orientation',
    icon: 'Sparkles'
  },
  {
    id: 'future-4',
    text: 'What future version of yourself are you building toward?',
    category: 'future-orientation',
    icon: 'ArrowUp'
  },
  {
    id: 'future-5',
    text: 'Write down one thing you\'re looking forward to.',
    category: 'future-orientation',
    icon: 'Sun'
  }
];

export const QUOTES = [
  { text: 'When we are no longer able to change a situation, we are challenged to change ourselves.', author: 'Viktor Frankl' },
  { text: 'Everything can be taken from a man but one thing: the last of the human freedoms — to choose one\'s attitude in any given set of circumstances.', author: 'Viktor Frankl' },
  { text: 'Hope is being able to see that there is light despite all of the darkness.', author: 'Desmond Tutu' },
  { text: 'Hope is the thing with feathers that perches in the soul.', author: 'Emily Dickinson' },
  { text: 'The very least you can do in your life is figure out what you hope for.', author: 'Barbara Kingsolver' }
];

export function getPromptForScore(score: number): DailyPrompt {
  const isLowHope = score <= 12;
  const isHighHope = score >= 21;
  
  let eligiblePrompts: DailyPrompt[];
  
  if (isLowHope) {
    eligiblePrompts = PROMPTS.filter(p => 
      p.category === 'small-wins' || p.category === 'therapeutic-connection'
    );
  } else if (isHighHope) {
    eligiblePrompts = PROMPTS.filter(p => 
      p.category === 'growth' || p.category === 'future-orientation'
    );
  } else {
    eligiblePrompts = PROMPTS;
  }
  
  const today = new Date().toDateString();
  const index = today.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return eligiblePrompts[index % eligiblePrompts.length];
}

export function getDailyQuote() {
  const today = new Date().toDateString();
  const index = today.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return QUOTES[index % QUOTES.length];
}