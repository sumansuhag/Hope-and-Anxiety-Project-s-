import { HopeScore, UserReflection, UserProfile } from '../types';

const STORAGE_KEYS = {
  SCORES: 'hopetrack_scores',
  REFLECTIONS: 'hopetrack_reflections',
  PROFILE: 'hopetrack_profile'
};

export function saveScore(score: HopeScore): void {
  const scores = getScores();
  const today = new Date().toDateString();
  
  // Remove existing score for today if any
  const filtered = scores.filter(s => s.date !== today);
  filtered.push(score);
  
  // Keep only last 30 days
  const trimmed = filtered.slice(-30);
  
  localStorage.setItem(STORAGE_KEYS.SCORES, JSON.stringify(trimmed));
}

export function getScores(): HopeScore[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.SCORES);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function getTodayScore(): HopeScore | null {
  const scores = getScores();
  const today = new Date().toDateString();
  return scores.find(s => s.date === today) || null;
}

export function saveReflection(reflection: UserReflection): void {
  const reflections = getReflections();
  const today = new Date().toDateString();
  
  // Remove existing reflection for today if any
  const filtered = reflections.filter(r => r.date !== today);
  filtered.push(reflection);
  
  localStorage.setItem(STORAGE_KEYS.REFLECTIONS, JSON.stringify(filtered));
}

export function getReflections(): UserReflection[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.REFLECTIONS);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function getTodayReflection(): UserReflection | null {
  const reflections = getReflections();
  const today = new Date().toDateString();
  return reflections.find(r => r.date === today) || null;
}

export function saveProfile(profile: UserProfile): void {
  localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
}

export function getProfile(): UserProfile {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
    return data ? JSON.parse(data) : { onboardingComplete: false };
  } catch {
    return { onboardingComplete: false };
  }
}

export function clearAllData(): void {
  Object.values(STORAGE_KEYS).forEach(key => {
    localStorage.removeItem(key);
  });
}